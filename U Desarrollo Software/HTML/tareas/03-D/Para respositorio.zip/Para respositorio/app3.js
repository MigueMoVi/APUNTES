const API = 'https://api.github.com';

const form             = document.querySelector('#form-buscar');
const input            = document.querySelector('#input-usuario');
const selectOrden      = document.querySelector('#select-orden');
const boton            = document.querySelector('#btn-buscar');
const estado           = document.querySelector('#estado');
const perfil           = document.querySelector('#perfil');
const seccionLenguajes = document.querySelector('#seccion-lenguajes');
const listaLenguajes   = document.querySelector('#lista-lenguajes');
const titulo           = document.querySelector('#titulo-repos');
const repos            = document.querySelector('#repos');
const btnCargarMas     = document.querySelector('#btn-cargar-mas');
const rateLimitTexto   = document.querySelector('#rate-limit');

let paginaActual = 1;
let usuarioActual = '';

// 1. Petición genérica con lectura de cabecera x-ratelimit-remaining
async function obtenerJSON(url) {
    const res = await fetch(url);

    // Leer cabecera x-ratelimit-remaining y actualizar el pie de página
    const limiteRestante = res.headers.get('x-ratelimit-remaining');
    if (limiteRestante !== null && rateLimitTexto) {
        rateLimitTexto.textContent = `Peticiones disponibles: ${limiteRestante}`;
    }

    if (res.status === 404) throw new Error('Usuario no encontrado');
    if (res.status === 403) {
        throw new Error('Límite de peticiones alcanzado');
    }
    if (!res.ok) throw new Error(`Error HTTP ${res.status}`);

    return res.json();
}

// 2. Pintar el perfil
function mostrarPerfil(u) {
    const img = document.createElement('img');
    img.src = u.avatar_url;
    img.alt = `Avatar de ${u.login}`;

    const nombre = document.createElement('h2');
    nombre.textContent = u.name ?? u.login;

    const datos = document.createElement('p');
    datos.textContent =
        `${u.public_repos} repositorios · ${u.followers} seguidores`;

    const enlace = document.createElement('a');
    enlace.href = u.html_url;
    enlace.target = '_blank';
    enlace.textContent = 'Ver en GitHub';

    const info = document.createElement('div');
    info.append(nombre, datos, enlace);
    perfil.replaceChildren(img, info);
    perfil.classList.remove('oculto');
}

// 3. Pintar el resumen de lenguajes más usados
function mostrarResumenLenguajes(listaRepos) {
    listaLenguajes.innerHTML = '';

    const conteoLenguajes = listaRepos.reduce((acc, repo) => {
        const lang = repo.language ?? 'Sin lenguaje';
        acc[lang] = (acc[lang] || 0) + 1;
        return acc;
    }, {});

    Object.entries(conteoLenguajes).forEach(([lenguaje, cantidad]) => {
        const li = document.createElement('li');
        li.textContent = `${lenguaje}: ${cantidad} repositorio(s)`;
        listaLenguajes.append(li);
    });

    seccionLenguajes.classList.remove('oculto');
}

// 4. Pintar la lista de repositorios (limpia si es la página 1, añade si es > 1)
function mostrarRepos(lista, limpiar = true) {
    if (limpiar) {
        repos.innerHTML = '';
    }

    lista.forEach(r => {
        const a = document.createElement('a');
        a.href = r.html_url;
        a.target = '_blank';
        a.textContent = r.name;

        const li = document.createElement('li');
        const lenguaje = r.language ?? 'sin lenguaje';
        li.append(a, ` - ${lenguaje} - ${r.stargazers_count}`);
        repos.append(li);
    });

    titulo.classList.remove('oculto');
}

// 5. Evento submit
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    usuarioActual = encodeURIComponent(input.value.trim());
    if (!usuarioActual) return;

    paginaActual = 1;
    const criterioOrden = selectOrden.value;

    const params = new URLSearchParams({ 
        sort: criterioOrden, 
        per_page: 5,
        page: paginaActual
    });

    boton.disabled = true;
    btnCargarMas.classList.add('oculto');
    estado.className = '';
    estado.textContent = 'Buscando...';

    try {
        const [datosUsuario, datosRepos] = await Promise.all([
            obtenerJSON(`${API}/users/${usuarioActual}`),
            obtenerJSON(`${API}/users/${usuarioActual}/repos?${params.toString()}`)
        ]);

        mostrarPerfil(datosUsuario);
        mostrarResumenLenguajes(datosRepos);
        mostrarRepos(datosRepos, true);
        estado.textContent = '';

        // Ocultar botón si trajo menos de 5 resultados
        if (datosRepos.length === 5) {
            btnCargarMas.classList.remove('oculto');
        } else {
            btnCargarMas.classList.add('oculto');
        }
    } catch (error) {
        perfil.classList.add('oculto');
        if (seccionLenguajes) seccionLenguajes.classList.add('oculto');
        titulo.classList.add('oculto');
        repos.innerHTML = '';
        btnCargarMas.classList.add('oculto');
        estado.className = 'error';
        estado.textContent = error.message;
    } finally {
        boton.disabled = false;
    }
});

// 6. Evento botón "Cargar más"
btnCargarMas.addEventListener('click', async () => {
    paginaActual++;
    const criterioOrden = selectOrden.value;

    const params = new URLSearchParams({ 
        sort: criterioOrden, 
        per_page: 5,
        page: paginaActual
    });

    btnCargarMas.disabled = true;

    try {
        const datosRepos = await obtenerJSON(`${API}/users/${usuarioActual}/repos?${params.toString()}`);
        mostrarRepos(datosRepos, false);

        if (datosRepos.length < 5) {
            btnCargarMas.classList.add('oculto');
        }
    } catch (error) {
        estado.className = 'error';
        estado.textContent = error.message;
    } finally {
        btnCargarMas.disabled = false;
    }
});

// Evento al cambiar la opción de orden
selectOrden.addEventListener('change', () => {
    if (input.value.trim()) {
        form.requestSubmit();
    }
});